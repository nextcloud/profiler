# Profiler

This app provides a profiler to find performance related issues

Don't use in a production system.

## How to use

1. Enable the app
2. Enable profiling by running `occ profiler:enable`
