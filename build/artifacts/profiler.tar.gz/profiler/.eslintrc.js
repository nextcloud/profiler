module.exports = {
	globals: {
		appName: true,
		appVersion: true,
		isTesting: true,
		oc_defaults: true,
	},
	extends: [
		'@nextcloud',
	],
}
